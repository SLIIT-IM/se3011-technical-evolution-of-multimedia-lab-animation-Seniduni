// ---------- GAME STATE ----------
int state = 0; // 0 = start, 1 = play, 2 = end
int startTime;
int duration = 30;

// ---------- PLAYER ----------
float px = 350, py = 175;
float pr = 20;
float step = 6;

// ---------- HELPER ----------
float hx, hy;
float ease = 0.08;

// ---------- ORB ----------
float ox, oy;
float or = 18;
float xs = 4, ys = 3;

// ---------- SCORE ----------
int score = 0;

// ---------- TRAILS ----------
boolean trails = false;

void setup() {
  size(1000, 500);
  resetGame();
}

void draw() {

  // ---------- TRAIL LOGIC ----------
  if (!trails) {
    background(255, 230, 0); // YELLOW background
  } else {
    noStroke();
    fill(255, 230, 0, 40); // yellow fade trail
    rect(0, 0, width, height);
  }

  // ---------- START SCREEN ----------
  if (state == 0) {
    textAlign(CENTER, CENTER);
    textSize(26);
    fill(30); // dark text
    text("Press ENTER to Start", width/2, height/2);
  }

  // ---------- PLAY STATE ----------
  if (state == 1) {

    // TIMER
    int elapsed = (millis() - startTime) / 1000;
    int left = duration - elapsed;

    if (left <= 0) {
      state = 2;
    }

    // PLAYER MOVEMENT
    if (keyPressed) {
      if (keyCode == RIGHT) px += step;
      if (keyCode == LEFT)  px -= step;
      if (keyCode == DOWN)  py += step;
      if (keyCode == UP)    py -= step;
    }

    px = constrain(px, pr, width - pr);
    py = constrain(py, pr, height - pr);

    // HELPER EASING
    hx += (px - hx) * ease;
    hy += (py - hy) * ease;

    // ORB MOVEMENT
    ox += xs;
    oy += ys;

    if (ox > width - or || ox < or) xs *= -1;
    if (oy > height - or || oy < or) ys *= -1;

    // COLLISION
    float d = dist(px, py, ox, oy);
    if (d < pr + or) {
      score++;

      ox = random(or, width - or);
      oy = random(or, height - or);

      xs *= 1.1;
      ys *= 1.1;
    }

    // DRAW ORB (RED)
    fill(255, 60, 60);
    ellipse(ox, oy, or*2, or*2);

    // DRAW PLAYER (BLUE)
    fill(0, 100, 255);
    ellipse(px, py, pr*2, pr*2);

    // DRAW HELPER (GREEN)
    fill(0, 200, 120);
    ellipse(hx, hy, 14, 14);

    // UI
    fill(30);
    textAlign(LEFT, TOP);
    textSize(16);
    text("Score: " + score, 20, 20);
    text("Time: " + left, 20, 40);
    text("Trails: " + (trails ? "ON" : "OFF") + " (T)", 20, 60);
  }

  // ---------- END SCREEN ----------
  if (state == 2) {
    textAlign(CENTER, CENTER);
    textSize(26);
    fill(30);
    text("Time Over!", width/2, height/2 - 30);
    text("Final Score: " + score, width/2, height/2);
    text("Press R to Restart", width/2, height/2 + 40);
  }
}

void keyPressed() {

  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
  }

  if (state == 2 && (key == 'r' || key == 'R')) {
    resetGame();
    state = 0;
  }

  if (key == 't' || key == 'T') {
    trails = !trails;
  }
}

void resetGame() {
  px = width/2;
  py = height/2;

  hx = px;
  hy = py;

  ox = random(or, width - or);
  oy = random(or, height - or);

  xs = 4;
  ys = 3;

  score = 0;
}
